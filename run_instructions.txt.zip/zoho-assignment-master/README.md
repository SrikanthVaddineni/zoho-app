# zoho-assignment
In this repositiory we can  use this  how to sign up to a account and  login to open a account for this application is used  and it will be used in our daily life like social media sites.
